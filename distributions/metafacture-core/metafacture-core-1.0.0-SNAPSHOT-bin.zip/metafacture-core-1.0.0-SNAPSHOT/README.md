![Metafacture](https://raw.github.com/wiki/culturegraph/metafacture-core/img/metafacture.png)

metafacture-core
================

Core package of the Metafacture tool suite for metadata processing. See the wiki for more information: https://github.com/culturegraph/metafacture-core/wiki
