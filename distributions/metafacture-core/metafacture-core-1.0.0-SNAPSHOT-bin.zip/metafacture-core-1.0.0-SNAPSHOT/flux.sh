#!/bin/bash

dir=`dirname $0`

jarfile="metafacture-core-1.0.0-SNAPSHOT.jar"

if uname | grep -iq cygwin; then
    java -jar `cygpath -am $dir/$jarfile` $*
else
    java -jar $dir/$jarfile $*
fi


