#!/bin/bash

dir=`dirname $0`

jarfile="metafacture-core-1.0.0.jar"

if uname | grep -iq cygwin; then
    java -Xmx512M -jar "`cygpath -am $dir/$jarfile`" $*
else
    java -Xmx512M -jar "$dir/$jarfile" $*
fi


